<?php 
include "config.php";

// if the form's submit button is clicked, we need to process the form
	if (isset($_POST['submit'])) {
		// get variables from the form
		$first_name = $_POST['firstname'];
		$last_name = $_POST['lastname'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$gender = $_POST['gender'];

		//write sql query

		$sql = "INSERT INTO `users`(`firstname`, `lastname`, `email`, `password`, `gender`) VALUES ('$first_name','$last_name','$email','$password','$gender')";

		// execute the query

		$result = $conn->query($sql);

		if ($result == TRUE) {
			echo "New record created successfully.";
		}else{
			echo "Error:". $sql . "<br>". $conn->error;
		}

		$conn->close();

	}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>books4u</title>
    <link rel="shortcut icon" type="image/x-icon" href="favicon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" />
    
</head>
<body>
<section class ="my-5 m-auto" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.5); width:600px;background:#; ">
      <div class="py-5" >
        <h2 class =text-center>Create book details</h2>
      </div>
  <div class="w-50 m-auto">
  
  

<form action="" method="POST">
<fieldset>
    <div class="form-group">
    <label>Books name:</label><br>
    <input type="text" name ="firstname" autocomplete="off" class="form-control" placeholder="Write here" >
    </div>
    <div class="form-group">
    <label>Price:</label><br>
    <input type="text" name ="lastname" autocomplete="off" class="form-control" placeholder="Write here" >
    </div>
    <br>
    <div class="form-group">
    <label>Author:</label><br>
    <input type="text" name ="password" autocomplete="off" class="form-control" placeholder="Write here" >
    </div>
    
    <br>
    
    <div class="form-group">
      <label for="email">Email:</label><br>
      <input type="email" class="form-control" id="email" name="email"  autocomplete="off" placeholder="Enter email"required >
    </div>
    <br>
    <div class="form-group">
    <label>Gender:</label><br>
    
    <input type="radio" name="gender" value="Male">Male
    <input type="radio" name="gender" value="Female">Female
    <br><br>
    </div>
    
    
    <button href="" type="submit" name="submit" class="btn btn-success">submit</button>
    <button href="view.php" type="submit" name="submit" class="btn btn-success" style="background:#5FB4D6;padding:5px;border-radius:5px">View</button>
   
  </form>
</div>


</section>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>   
</body>
</html>